import collections
import re

from content import DOMAIN_ORDER
from question_bank import ALL_QUESTIONS, CHAPTERS, LESSONS_BY_KEY, E_OPTION, to_streamlit_math, validate_bank


def test_bank_has_no_structural_problems():
    assert validate_bank() == []


def test_all_seven_domains_have_lessons_and_questions():
    for domain in DOMAIN_ORDER:
        assert CHAPTERS[domain], domain
        assert any(q["domain"] == domain for q in ALL_QUESTIONS), domain


def test_expected_lesson_counts():
    counts = {d: len(CHAPTERS[d]) for d in DOMAIN_ORDER}
    assert counts["Structura atomului"] == 8
    assert counts["Legături chimice"] == 9
    assert counts["Soluții"] == 8
    assert counts["Legile gazelor"] == 8
    assert counts["Procese de oxidare și reducere"] == 10
    assert counts["Introducere în chimia organică"] >= 10
    assert counts["Hidrocarburi"] >= 10


def test_question_ids_unique_and_questions_not_duplicated():
    ids = [q["id"] for q in ALL_QUESTIONS]
    assert len(ids) == len(set(ids))
    texts = collections.Counter(re.sub(r"\s+", " ", q["question"].lower()) for q in ALL_QUESTIONS)
    assert [t for t, c in texts.items() if c > 1] == []


def test_each_question_has_five_options_answer_and_explanations():
    for q in ALL_QUESTIONS:
        assert len(q["options"]) == 5, q["id"]
        assert q["options"][4] == E_OPTION, q["id"]
        assert q["answer"] in q["options"], q["id"]
        assert len(q["explanation"]) >= 20, q["id"]
        wrong = [l for l in "ABCDE" if l != q["answer"][0]]
        assert sorted(q["option_explanations"]) == wrong, q["id"]


def test_lesson_field_format_is_consistent():
    for q in ALL_QUESTIONS:
        chapter = DOMAIN_ORDER.index(q["domain"]) + 1
        assert re.fullmatch(rf"{chapter}\.\d+", q["lesson"]), q["id"]
        assert (q["domain"], q["lesson"]) in LESSONS_BY_KEY, q["id"]


def test_every_lesson_has_theory_takeaways_and_questions():
    for domain, lessons in CHAPTERS.items():
        for lesson in lessons:
            assert len(lesson["body"]) > 600, lesson["id"]
            assert lesson["takeaways"] and lesson["objectives"] and lesson["mistakes"], lesson["id"]
            assert any(q["lesson"] == lesson["number"] and q["domain"] == domain for q in ALL_QUESTIONS), lesson["id"]


def test_no_old_redox_demo_questions_in_bank():
    ids = {q["id"] for q in ALL_QUESTIONS}
    assert not {"redox_01", "redox_02", "org_01", "hydro_01"} & ids


def test_math_conversion_for_streamlit():
    text = to_streamlit_math(r"Avem \(n=2,5\) și \[pV=nRT\]")
    assert "$n=2{,}5$" in text and "$$\npV=nRT\n$$" in text
    assert "\\[" not in text and "\\(" not in text
    for domain, lessons in CHAPTERS.items():
        for lesson in lessons:
            assert "\\[" not in lesson["body"] and "\\(" not in lesson["body"], lesson["id"]
