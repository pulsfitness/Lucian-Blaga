import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


@pytest.fixture()
def temp_db(tmp_path, monkeypatch):
    """Fiecare test lucrează pe o bază SQLite temporară; data/laborator.db nu este atinsă."""
    path = tmp_path / "laborator_test.db"
    monkeypatch.setenv("LAB_DB_PATH", str(path))
    monkeypatch.setenv("LAB_STORAGE", "local")
    return path
