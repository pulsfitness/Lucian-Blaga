import progress

DOMAINS = ["D1", "D2", "D3"]


def att(i, domain, lesson, correct, ts, qid=None):
    return {"id": i, "question_id": qid or f"q{i}", "domain": domain, "lesson": lesson, "topic": "t",
            "question": "?", "chosen": "A", "answer": "B", "correct": int(correct), "created_at": ts}


ROWS = [
    att(1, "D1", "1.1", True, "2026-11-01 08:00:00"),
    att(2, "D1", "1.1", True, "2026-11-01 09:00:00"),
    att(3, "D1", "1.2", True, "2026-11-02 08:00:00"),
    att(4, "D1", "1.2", True, "2026-11-02 09:00:00"),
    att(5, "D2", "2.1", False, "2026-11-02 10:00:00", qid="x"),
    att(6, "D2", "2.1", False, "2026-11-03 10:00:00", qid="x"),
    att(7, "D2", "2.1", False, "2026-11-03 11:00:00", qid="y"),
    att(8, "D2", "2.2", True, "2026-11-03 12:00:00"),
]


def test_summary_counts_and_rate():
    s = progress.summary(ROWS)
    assert (s["total"], s["correct"], s["wrong"]) == (8, 5, 3)
    assert abs(s["rate"] - 5 / 8) < 1e-9
    assert s["distinct_questions"] == 7


def test_by_domain_includes_untouched_domains():
    d = {r["domain"]: r for r in progress.by_domain(ROWS, DOMAINS)}
    assert (d["D1"]["total"], d["D1"]["correct"]) == (4, 4)
    assert (d["D2"]["total"], d["D2"]["correct"]) == (4, 1)
    assert d["D3"]["total"] == 0


def test_timeline_is_grouped_per_romanian_day_with_cumulative_rate():
    tl = progress.timeline(ROWS)
    assert [t["day"] for t in tl] == ["2026-11-01", "2026-11-02", "2026-11-03"]
    assert [t["total"] for t in tl] == [2, 3, 3]
    assert abs(tl[-1]["cumulative_rate"] - 5 / 8) < 1e-9


def test_timezone_conversion_moves_late_utc_answer_to_next_day():
    tl = progress.timeline([att(1, "D1", "1.1", True, "2026-11-01 23:30:00")])  # 01:30 în România
    assert tl[0]["day"] == "2026-11-02"


def test_strengths_and_weaknesses_from_real_data():
    mistakes = progress.latest_mistakes(ROWS)
    sw = progress.strengths_and_weaknesses(ROWS, DOMAINS, mistakes)
    assert [d["domain"] for d in sw["strong"]] == ["D1"]
    assert [d["domain"] for d in sw["weak"]] == ["D2"]
    assert any(l["lesson"] == "2.1" for l in sw["weak_lessons"])
    assert [d["domain"] for d in sw["untouched"]] == ["D3"]


def test_open_mistakes_exclude_recovered_questions():
    rows = ROWS + [att(9, "D2", "2.1", True, "2026-11-04 10:00:00", qid="x")]
    mistakes = {m["question_id"]: m for m in progress.latest_mistakes(rows)}
    assert mistakes["x"]["last_correct"] == 1 and mistakes["x"]["wrong_count"] == 2
    assert [m["question_id"] for m in progress.open_mistakes(list(mistakes.values()))] == ["y"]
