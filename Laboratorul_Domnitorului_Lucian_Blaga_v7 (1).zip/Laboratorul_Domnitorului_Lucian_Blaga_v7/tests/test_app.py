"""Teste ale interfeței cu streamlit.testing (aplicația rulează fără browser)."""
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

import database
from content import DOMAIN_ORDER
from question_bank import ALL_QUESTIONS, CHAPTERS

APP = str(Path(__file__).resolve().parents[1] / "app.py")


def new_app():
    at = AppTest.from_file(APP, default_timeout=60)
    at.run()
    assert not at.exception, at.exception
    return at


def goto(at, page):
    at.sidebar.radio(key="nav").set_value(page).run()
    assert not at.exception, at.exception


def test_every_page_renders(temp_db):
    at = new_app()
    text = " ".join(m.value for m in at.markdown)
    assert "LABORATORUL OFICIAL AL DOMNITORULUI LUCIAN BLAGA" in text
    assert "spor la învățare gang!!" in text and "Chimia nu se învață singură. Din păcate." in text
    for page in ["Programa concursului", "Material de studiu", "Teste pe domenii", "Urmărirea greșelilor",
                 "Panou de progres", "Provocarea zilei"]:
        goto(at, page)


def test_every_lesson_opens_with_theory_and_takeaways(temp_db):
    at = new_app()
    goto(at, "Material de studiu")
    for domain in DOMAIN_ORDER:
        at.selectbox(key="study_domain").set_value(domain).run()
        for lesson in CHAPTERS[domain]:
            at.selectbox(key="study_lesson").set_value(lesson["title"]).run()
            assert not at.exception, (lesson["id"], at.exception)
            shown = " ".join(m.value for m in at.markdown)
            assert lesson["takeaways"][0] in shown, lesson["id"]
            assert any(lesson["title"] == h.value for h in at.subheader), lesson["id"]


def test_answering_saves_attempt_and_shows_explanations(temp_db):
    at = new_app()
    goto(at, "Teste pe domenii")
    domain = "Procese de oxidare și reducere"
    at.selectbox(key="test_domain").set_value(domain).run()
    q = next(x for x in ALL_QUESTIONS if x["domain"] == domain)
    wrong = next(o for o in q["options"] if o != q["answer"])
    at.radio(key=f"choice_t_{q['id']}").set_value(wrong).run()
    at.button(key=f"check_t_{q['id']}").click().run()
    assert not at.exception
    assert any(q["answer"] in e.value for e in at.error)
    assert len(database.get_attempts()) == 1 and database.get_attempts()[0]["lesson"] == q["lesson"]
    # explicațiile apar (răspuns corect + distractori)
    shown = " ".join(m.value for m in at.markdown)
    assert q["explanation"][:40] in shown
    # greșeala apare în tracker și poate fi reluată
    goto(at, "Urmărirea greșelilor")
    at.radio(key=f"choice_m_{q['id']}").set_value(q["answer"]).run()
    at.button(key=f"check_m_{q['id']}").click().run()
    assert not at.exception
    rows = database.get_attempts()
    assert len(rows) == 2 and rows[-1]["source"] == "mistake_retry" and rows[-1]["correct"] == 1
    [m] = database.get_mistakes()
    assert m["last_correct"] == 1 and m["chosen"] == wrong


def test_daily_challenge_is_saved_once_even_after_reload(temp_db):
    at = new_app()
    goto(at, "Provocarea zilei")
    radio = next(r for r in at.radio if r.key and r.key.startswith("daily_choice_"))
    radio.set_value(radio.options[0]).run()
    at.button(key="daily_check").click().run()
    assert not at.exception
    assert len([a for a in database.get_attempts() if a["source"] == "daily"]) == 1
    # „reîncărcare”: o sesiune nouă a aplicației, aceeași zi
    at2 = new_app()
    goto(at2, "Provocarea zilei")
    assert any("Ai rezolvat deja provocarea de azi" in i.value for i in at2.info)
    assert not any(r.key and r.key.startswith("daily_choice_") for r in at2.radio)
    assert len([a for a in database.get_attempts() if a["source"] == "daily"]) == 1


def test_dashboard_statistics_come_from_history(temp_db):
    database.init_db()
    q = ALL_QUESTIONS[0]
    database.save_answer(q, q["answer"], True)
    database.save_answer(q, next(o for o in q["options"] if o != q["answer"]), False)
    at = new_app()
    goto(at, "Panou de progres")
    values = {m.label: m.value for m in at.metric}
    assert values["Încercări"] == "2" and values["Corecte"] == "1" and values["Greșite"] == "1"
    assert values["Procent corecte"] == "50%"
