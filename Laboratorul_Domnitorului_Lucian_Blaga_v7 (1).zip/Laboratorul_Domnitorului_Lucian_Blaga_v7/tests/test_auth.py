"""Autentificarea Google prin Supabase: configurare, URL PKCE, erori clare, expirarea sesiunii."""
import time
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parents[1] / "app.py")
SECRETS = {"supabase": {"url": "https://exemplu-test.supabase.co", "anon_key": "sb_publishable_test",
                        "redirect_url": "http://localhost:8501"}}


def online_app(monkeypatch, tmp_path):
    monkeypatch.setenv("LAB_DB_PATH", str(tmp_path / "x.db"))
    monkeypatch.delenv("LAB_STORAGE", raising=False)
    at = AppTest.from_file(APP, default_timeout=60)
    at.secrets["supabase"] = SECRETS["supabase"]
    return at


def test_login_link_uses_google_and_pkce(monkeypatch, tmp_path):
    at = online_app(monkeypatch, tmp_path)
    at.run()
    assert not at.exception
    html = " ".join(m.value for m in at.sidebar.markdown)
    assert "Conectează-te cu Google" in html
    url = html.split('href="')[1].split('"')[0].replace("&amp;", "&")
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    assert parsed.netloc == "exemplu-test.supabase.co" and parsed.path == "/auth/v1/authorize"
    assert qs["provider"] == ["google"]
    assert qs["code_challenge_method"] == ["s256"] and qs["code_challenge"][0]
    assert qs["redirect_to"][0].startswith("http://localhost:8501/?lab_state=")
    assert "password" not in url.lower()


def test_guest_mode_does_not_write_local_database(monkeypatch, tmp_path):
    at = online_app(monkeypatch, tmp_path)
    at.run()
    assert any("Mod vizitator" in c.value for c in at.caption)
    from question_bank import ALL_QUESTIONS
    q = ALL_QUESTIONS[0]
    at.sidebar.radio(key="nav").set_value("Teste pe domenii").run()
    at.radio(key=f"choice_t_{q['id']}").set_value(q["answer"]).run()
    at.button(key=f"check_t_{q['id']}").click().run()
    assert not at.exception
    assert any("Corect" in s.value for s in at.success)
    assert len(at.session_state["guest_attempts"]) == 1
    db = tmp_path / "x.db"
    if db.exists():
        import sqlite3
        assert sqlite3.connect(db).execute("select count(*) from answers").fetchone()[0] == 0


def test_callback_with_unknown_state_shows_clear_error(monkeypatch, tmp_path):
    at = online_app(monkeypatch, tmp_path)
    at.query_params["code"] = "cod-fals"
    at.query_params["lab_state"] = "necunoscut"
    at.run()
    assert not at.exception
    assert any("expirat" in e.value for e in at.error)


def test_callback_with_access_denied_is_explained(monkeypatch, tmp_path):
    at = online_app(monkeypatch, tmp_path)
    at.query_params["error"] = "access_denied"
    at.query_params["error_description"] = "User denied"
    at.run()
    assert any("anulată" in w.value for w in at.warning)


def test_expired_session_that_cannot_refresh_logs_out(monkeypatch, tmp_path):
    import auth

    def boom(*a, **k):
        raise RuntimeError("refresh failed")

    at = online_app(monkeypatch, tmp_path)
    at.session_state["lab_auth"] = {"access_token": "x", "refresh_token": "y", "expires_at": int(time.time()) - 10,
                                    "user_id": "11111111-1111-1111-1111-111111111111", "email": "a@x.ro", "name": "A"}
    monkeypatch.setattr(auth, "_client", lambda *a, **k: type("C", (), {"auth": type("A", (), {"refresh_session": boom})()})())
    at.run()
    assert not at.exception
    assert any("Sesiunea a expirat" in w.value for w in at.warning)
    assert "lab_auth" not in at.session_state
