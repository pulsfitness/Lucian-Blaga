import sqlite3
import time

import database
import progress
from question_bank import ALL_QUESTIONS

Q1, Q2 = ALL_QUESTIONS[0], ALL_QUESTIONS[1]


def wrong_options(q):
    return [o for o in q["options"] if o != q["answer"]]


def test_history_is_kept_for_repeated_answers(temp_db):
    database.init_db()
    for _ in range(3):
        database.save_answer(Q1, wrong_options(Q1)[0], False)
    database.save_answer(Q1, Q1["answer"], True)
    assert len(database.get_attempts()) == 4
    assert database.get_summary() == {"total": 4, "correct": 1, "wrong": 3}


def test_get_mistakes_uses_latest_wrong_attempt(temp_db):
    database.init_db()
    first, second = wrong_options(Q1)[0], wrong_options(Q1)[1]
    with database.connect() as c:  # date controlate: încercarea mai nouă are id mai mare
        c.execute("INSERT INTO answers(question_id,domain,topic,question,chosen,answer,correct,created_at) "
                  "VALUES(?,?,?,?,?,?,0,'2026-01-01 10:00:00')", (Q1["id"], Q1["domain"], Q1["topic"], Q1["question"], first, Q1["answer"]))
        c.execute("INSERT INTO answers(question_id,domain,topic,question,chosen,answer,correct,created_at) "
                  "VALUES(?,?,?,?,?,?,0,'2026-02-01 10:00:00')", (Q1["id"], Q1["domain"], Q1["topic"], Q1["question"], second, Q1["answer"]))
        c.execute("INSERT INTO answers(question_id,domain,topic,question,chosen,answer,correct,created_at) "
                  "VALUES(?,?,?,?,?,?,1,'2026-03-01 10:00:00')", (Q1["id"], Q1["domain"], Q1["topic"], Q1["question"], Q1["answer"], Q1["answer"]))
    [m] = database.get_mistakes()
    assert m["chosen"] == second
    assert m["latest"] == "2026-02-01 10:00:00"
    assert m["attempts"] == 3 and m["wrong_count"] == 2 and m["last_correct"] == 1


def test_sql_and_python_mistakes_agree(temp_db):
    database.init_db()
    import random
    rnd = random.Random(7)
    for _ in range(60):
        q = rnd.choice(ALL_QUESTIONS[:8])
        ok = rnd.random() < 0.4
        database.save_answer(q, q["answer"] if ok else rnd.choice(wrong_options(q)), ok)
    sql = {m["question_id"]: (m["chosen"], m["attempts"], m["wrong_count"], m["last_correct"]) for m in database.get_mistakes()}
    py = {m["question_id"]: (m["chosen"], m["attempts"], m["wrong_count"], m["last_correct"])
          for m in progress.latest_mistakes(database.get_attempts())}
    assert sql == py


def test_daily_challenge_recorded_only_once(temp_db):
    database.init_db()
    assert database.save_daily("2026-11-21", Q2, Q2["answer"], True) is True
    assert database.save_daily("2026-11-21", Q2, wrong_options(Q2)[0], False) is False
    assert database.get_daily("2026-11-21")["chosen"] == Q2["answer"]
    daily = [a for a in database.get_attempts() if a["source"] == "daily"]
    assert len(daily) == 1


def test_existing_v6_database_is_migrated_without_data_loss(temp_db):
    conn = sqlite3.connect(temp_db)  # schema exactă din versiunea 6
    conn.execute("""CREATE TABLE answers(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id TEXT NOT NULL,
        domain TEXT NOT NULL, topic TEXT NOT NULL, question TEXT NOT NULL, chosen TEXT NOT NULL,
        answer TEXT NOT NULL, correct INTEGER NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("INSERT INTO answers(question_id,domain,topic,question,chosen,answer,correct) VALUES('gas_05','Legile gazelor','t','q','A','B',0)")
    conn.commit(); conn.close()
    database.init_db(); database.init_db()  # idempotent
    rows = database.get_attempts()
    assert len(rows) == 1 and rows[0]["question_id"] == "gas_05" and rows[0]["source"] == "test"
    database.save_answer(Q1, Q1["answer"], True)
    assert len(database.get_attempts()) == 2
