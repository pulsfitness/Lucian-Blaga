"""Validator pentru modulele de capitol. Utilizare: python3 validate_chapter.py path/to/chapterN.py [--strict-lessons]"""
import importlib.util, re, sys, collections
from pathlib import Path

REQUIRED_SECTIONS = ["## Explicație teoretică", "## Definiții și concepte importante", "## Formule și relații",
                     "## Exemple rezolvate pas cu pas", "## Interpretarea rezultatelor"]
E_TEXT = "E. Niciuna dintre variantele A–D"

def load(path):
    spec = importlib.util.spec_from_file_location(Path(path).stem, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def main(path):
    mod = load(path)
    n = re.search(r"chapter(\d+)", Path(path).stem).group(1)
    L = getattr(mod, f"CHAPTER{n}_LESSONS"); Q = getattr(mod, f"CHAPTER{n}_QUESTIONS"); D = getattr(mod, "DOMAIN")
    err = []
    numbers = []
    ids = set()
    for i, l in enumerate(L):
        tag = l.get("id", f"lesson#{i}")
        for k in ["id","number","title","level","official","objectives","body","mistakes","takeaways","connections"]:
            if not l.get(k): err.append(f"{tag}: câmp lipsă/gol {k}")
        if l.get("id") in ids: err.append(f"{tag}: id duplicat")
        ids.add(l.get("id"))
        num = l.get("number", "")
        numbers.append(num)
        if not re.fullmatch(rf"{n}\.\d+", num or ""): err.append(f"{tag}: number invalid {num!r}")
        if not l.get("title","").startswith(f"{num}. "): err.append(f"{tag}: titlul nu începe cu '{num}. '")
        body = l.get("body","")
        pos = -1
        for s in REQUIRED_SECTIONS:
            p = body.find("\n"+s) if not body.startswith(s) else 0
            if p < 0: err.append(f"{tag}: lipsește secțiunea {s!r}")
            elif p < pos: err.append(f"{tag}: secțiunea {s!r} nu e în ordine")
            else: pos = p
        if "\\[" in body or "\\(" in body: err.append(f"{tag}: folosește \\[ sau \\( (interzis; folosește $$ / $)")
        if "\\ce{" in body: err.append(f"{tag}: folosește \\ce")
        if body.count("$$") % 2: err.append(f"{tag}: număr impar de $$")
        single = body.replace("$$","")
        if single.count("$") % 2: err.append(f"{tag}: număr impar de $ inline")
        if len(body) < 3500: err.append(f"{tag}: body prea scurt ({len(body)} caractere)")
        if body.count("### Exemplul") < 2: err.append(f"{tag}: mai puțin de 2 exemple rezolvate ('### Exemplul')")
        if not (3 <= len(l.get("objectives",[])) <= 6): err.append(f"{tag}: 3–6 obiective")
        if not (3 <= len(l.get("mistakes",[]))): err.append(f"{tag}: minim 3 greșeli frecvente")
        if not (4 <= len(l.get("takeaways",[]))): err.append(f"{tag}: minim 4 idei esențiale")
    if len(set(numbers)) != len(numbers): err.append("numere de lecție duplicate")
    qids = set(); texts = collections.Counter(); per_lesson = collections.Counter(); answers = collections.Counter()
    for q in Q:
        tag = q.get("id","?")
        for k in ["id","domain","lesson","topic","level","type","question","options","answer","explanation","option_explanations"]:
            if not q.get(k): err.append(f"{tag}: câmp lipsă/gol {k}")
        if tag in qids: err.append(f"{tag}: id duplicat")
        qids.add(tag)
        if q.get("domain") != D: err.append(f"{tag}: domain diferit de DOMAIN")
        if q.get("lesson") not in numbers: err.append(f"{tag}: lesson {q.get('lesson')!r} inexistentă")
        per_lesson[q.get("lesson")] += 1
        if q.get("type") not in ("teorie","calcul","interpretare","aplicație"): err.append(f"{tag}: type invalid")
        opts = q.get("options", [])
        if len(opts) != 5: err.append(f"{tag}: nu are 5 variante")
        else:
            for letter, o in zip("ABCDE", opts):
                if not o.startswith(letter + ". "): err.append(f"{tag}: varianta {letter} prefix greșit")
            if opts[4] != E_TEXT: err.append(f"{tag}: E trebuie să fie exact {E_TEXT!r}")
            if len(set(o[3:].strip().lower() for o in opts)) != 5: err.append(f"{tag}: variante identice")
        ans = q.get("answer")
        if ans not in opts: err.append(f"{tag}: answer nu e printre variante")
        else:
            answers[ans[0]] += 1
            oe = q.get("option_explanations", {})
            for letter in "ABCDE":
                if letter == ans[0]:
                    if letter in oe: err.append(f"{tag}: option_explanations conține răspunsul corect")
                elif not oe.get(letter): err.append(f"{tag}: lipsește explicația pentru varianta {letter}")
            extra = set(oe) - set("ABCDE")
            if extra: err.append(f"{tag}: chei invalide în option_explanations {extra}")
        if len(q.get("explanation","")) < 60: err.append(f"{tag}: explicație prea scurtă")
        texts[q.get("question","").strip().lower()] += 1
        for field in ["question","explanation"] + []:
            v = q.get(field, "")
            if v.replace("$$","").count("$") % 2: err.append(f"{tag}: $ impar în {field}")
            if "\\[" in v or "\\(" in v or "\\ce{" in v: err.append(f"{tag}: delimitatori LaTeX interziși în {field}")
    for t, c in texts.items():
        if c > 1: err.append(f"întrebare duplicată: {t[:60]}")
    for num in numbers:
        if per_lesson[num] < 2: err.append(f"lecția {num}: mai puțin de 2 întrebări ({per_lesson[num]})")
    if answers["E"] < 3: err.append(f"prea puține întrebări cu răspuns E ({answers['E']}); minim 3")
    print(f"Lecții: {len(L)} · Întrebări: {len(Q)} · Distribuție răspunsuri: {dict(sorted(answers.items()))}")
    print("Întrebări pe lecție:", dict(per_lesson))
    if err:
        print(f"\n{len(err)} PROBLEME:"); [print(" -", e) for e in err]; sys.exit(1)
    print("OK – validare trecută.")

if __name__ == "__main__":
    main(sys.argv[1])
