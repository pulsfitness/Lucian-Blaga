"""Verifică conservarea atomilor și a sarcinii într-o ecuație.
Utilizare: python3 balance_check.py "2KMnO4 + 16HCl -> 2KCl + 2MnCl2 + 5Cl2 + 8H2O"
Sarcini: sufix ^2+, ^-, ^3- ; electroni: e^-  (ex. "5e^-"). Paranteze: Ca(OH)2. Hidrați: CuSO4*5H2O
"""
import re, sys
from collections import Counter

def parse_formula(f):
    f = f.strip()
    charge = 0
    m = re.search(r"\^(\d*)([+-])$", f)
    if m:
        charge = int(m.group(1) or 1) * (1 if m.group(2) == "+" else -1)
        f = f[:m.start()]
    if f == "e":
        return Counter(), charge
    total = Counter()
    for part in f.split("*"):
        mm = re.match(r"^(\d+)(.*)$", part); mult = 1
        if mm and part[0].isdigit(): mult = int(mm.group(1)); part = mm.group(2)
        for k, v in _parse(part).items(): total[k] += v * mult
    return total, charge

def _parse(s):
    stack = [Counter()]; i = 0
    while i < len(s):
        ch = s[i]
        if ch in "([":
            stack.append(Counter()); i += 1
        elif ch in ")]":
            i += 1; m = re.match(r"\d+", s[i:]); n = int(m.group()) if m else 1
            if m: i += len(m.group())
            top = stack.pop()
            for k, v in top.items(): stack[-1][k] += v * n
        else:
            m = re.match(r"([A-Z][a-z]?)(\d*)", s[i:])
            if not m: raise ValueError(f"Nu pot interpreta {s[i:]!r}")
            stack[-1][m.group(1)] += int(m.group(2) or 1); i += len(m.group())
    return stack[0]

def side(expr):
    atoms = Counter(); charge = 0
    for term in expr.split(" + "):
        term = term.strip()
        m = re.match(r"^(\d+)\s*(.+)$", term)
        coef, sp = (int(m.group(1)), m.group(2)) if m else (1, term)
        a, c = parse_formula(sp)
        for k, v in a.items(): atoms[k] += coef * v
        charge += coef * c
    return atoms, charge

def check(eq):
    left, right = re.split(r"\s*(?:->|→|=)\s*", eq)
    la, lc = side(left); ra, rc = side(right)
    ok = la == ra and lc == rc
    print(("OK  " if ok else "FAIL") + f"  {eq}")
    if not ok:
        print("   stânga:", dict(la), "sarcină", lc); print("   dreapta:", dict(ra), "sarcină", rc)
    return ok

if __name__ == "__main__":
    res = [check(e) for e in sys.argv[1:]]
    sys.exit(0 if all(res) else 1)
